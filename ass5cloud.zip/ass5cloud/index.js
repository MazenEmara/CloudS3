const AWS = require('aws-sdk');
const s3= new AWS.S3();
const fs = require('fs')


s3.putObject({
    Bucket:"assbucket",
    Key: 'dummy.json',
    Body: fs.readFileSync('dummy.json')
}).promise();

/*
const file = fs.createWriteStream('./dummy.json');
s3.getObject({
    Bucket:"assbucket",
    Key: 'dummy.json'
},function(err,data){
    if(err) console.log(err,err.stack);
    else console.log(data)
}).createReadStream().pipe(file);


s3.deleteObject({
    Bucket:"assbucket",
    Key: 'dummy.json'
},function(err, data) {
    if (err) {
        console.log('Error deleting object: ', err);
    } else {
        console.log('Object deleted successfully: ', data);
    }
});*/